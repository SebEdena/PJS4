<?php 
function accueil()
{
	require('./Vue/accueil.tpl');
}

?>