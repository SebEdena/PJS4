<?php 
	function initSelection()
	{
		require("./Modele/cherchePartie.php");
		$tableauNiveau = listeNiveau();
		print_r($_SESSION);
		require("./Vue/choixClassement.tpl");
		
	}


	function rechercheClassement()
	{ 
		if(isset($_POST['classementRecherche'])){

						$id_niveau = $_POST['classementRecherche'];
				require("./Modele/cherchePartie.php");

			$res = chercheInfosPartie($id_niveau);

//echo(var_dump($res));
echo((json_encode($res)));

}
			//echo ($_POST[classementRecherche]);
	/*
		if($_POST['classementRecherche'] == "")
		{
			header("Location:index.php?controle=classement&action=initSelection");
		}
		else
		{
			$id_niveau = $_POST['classementRecherche'];
			//print_r($id_niveau);
			require("./Modele/cherchePartie.php");
			$res = chercheInfosPartie($id_niveau);
			//print_r($res);
			//On cherche le nom du niveau
			$libelleNiveau = chercheLibelleNiveau($id_niveau);
				
			require("./Vue/classement.tpl"); 
		}*/


	}
?>