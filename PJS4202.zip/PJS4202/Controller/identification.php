<?php
//Vérification des personnages (étudiant ou professeur)


function ident(){
	
	
	$Nom=  isset($_POST['Nom'])?($_POST['Nom']):'';
	$mdp=  isset($_POST['mdp'])?($_POST['mdp']):'';
	$msg='';
	$utilisateur;
	
	if  (count($_POST)==0) {
		require ("./Vue/Ident.tpl") ;
		}
	else {
	require ("./Modele/utilisateurBD.php") ;    //Vérifie l'utilisateur avec la base
		if  (!( verif_ident($Nom,$mdp,$profil,$utilisateur))) {
			$msg ="erreur de saisie";
			echo($msg);
			require ("vue/Ident.tpl") ;
			

		}
		else 
		{ 	
			$_SESSION['profil'] = $profil;
			//print_r($_SESSION);
			//require("./Vue/test.tpl");
			header('Location:index.php?controle=classement&action=initselection');	
		}
	}	
}
?>