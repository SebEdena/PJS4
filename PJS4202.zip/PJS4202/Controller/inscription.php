<?php
	
function inscription(){
	if(empty($_POST)){
		require("./Vue/form_inscription.tpl");
	}
	else{
		
		require("./Modele/inscrireBD.php");
		
		$pseudo = $_POST['pseudo'];
		$mail = $_POST['email'];
		
		$mdp = $_POST['pass'];
		
		inscrireJoueur($pseudo,$mail,$mdp);
		
		header('Location: ./index.php?controle=identification&action=ident');
		//require("./Vue/Ident.tpl");
		
	}
}

function retour()
{
	header('Location: ./index.php?controle=identification&action=ident');
}
?>