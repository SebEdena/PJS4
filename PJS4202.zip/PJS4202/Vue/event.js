function Rech(idNiv) {

    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'http://localhost/PJS4202/index.php?controle=classement&action=rechercheClassement');

    xhr.addEventListener('readystatechange', function() {
        if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
            // Votre code…
         //alert(xhr.response);
            displayResults(xhr.responseText, document);

        }
    });

    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.send('classementRecherche=' + idNiv);
}

function displayResults(response, doc) {
    //alert("a");
    //results.style.display = response.length ? 'block' : 'none';
    results.innerHTML = '';
    div = results.appendChild(document.createElement('div'));
var text = '';

    text = '<table class="table">';
    text += '<thead>';
    text += '<tr><th>Pseudo</th><th>Score</th></tr>';
    text += '</thead>';

    var obj = eval("(" + response + ')');
    text += '<tbody>';


    for (var i = 0; i < obj.length; i++) {
        text += '<tr>';

        text += '<td>' + obj[i]['pseudo'] + '</td><td>' + obj[i]['score'] + '</td>';

        text += '</tr>';

    }
    text += '</tbody>';
    text += '</table>';

div.innerHTML=text;

//alert(div.innerHTML);


}