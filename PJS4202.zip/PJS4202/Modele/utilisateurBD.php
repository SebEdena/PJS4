<?php
//Vérifie identifiant 
function verif_ident($nom,$num,&$profil,&$utilisateur ) {
	require ("./Modele/connectBD.php") ; 
	
	
	$select= "select * from Joueur where pseudo='%s' and passe='%s'";

	$req = sprintf($select,$nom,$num);
	
	$res = mysqli_query($link, $req)	
		or die (utf8_encode("erreur de requête : ") . $req); 

	if (mysqli_num_rows ($res) > 0) {
			$f = utf8_encode('Résultat de la base : <br/>');
			$profil = mysqli_fetch_assoc($res);
		return true;

	}

	else
	{
		return false;
	}
}

?>