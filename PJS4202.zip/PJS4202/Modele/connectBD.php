<?php

//chez vous, par exemple
$hote='localhost';   		
$login='root';  	
$pass=''; 		
$bd='pjs4'; //nom de la base de donnée utilisé pour le projet


/* //à l'iut
$hote="vs-wamp";   		
$login="pweb13_...";  		
$pass="..."; 			
$bd=$login; //ici la base a comme nom $login
*/

$link = mysqli_connect($hote, $login, $pass) 
		or die ("erreur de connexion :" . mysql_error()); 
	mysqli_select_db($link, $bd) 
		or die (utf8_encode("erreur d'accès à la base :") . $bd);
?>