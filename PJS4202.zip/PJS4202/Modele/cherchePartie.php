<?php 

function connexion(){
	$hote = 'localhost';
	$login = 'root';
	$pass = '';
	$bd = 'PJS4';
	
	require ("./Modele/connectBD.php") ; 
	$link = mysqli_connect($hote, $login, $pass) 
		or die ("erreur de connexion :" . mysql_error()); 
	mysqli_select_db($link, $bd) 
		or die (utf8_encode("erreur d'accès à la base :") . $bd);
	return $link;
}

function chercheInfosPartie($id_niveau){
	$link = connexion();
	$select= "select j.pseudo, pa.score From Joueur j, Partie pa Where pa.idNiveau='%s' and j.idJoueur = pa.idJoueur and pa.score = 
			(Select max(score) from Partie Where idJoueur = pa.idJoueur and pa.idNiveau = idNiveau) ORDER BY pa.score DESC "; 
	$req = sprintf($select, $id_niveau);
	
	$res = mysqli_query($link, $req)	
		or die (utf8_encode("erreur de requête : ") . $req); 

		
	$Resultat= array();
	while ($ligne = mysqli_fetch_assoc($res) and isset($ligne)) {
			//echo ("<pre>"); var_dump($c); echo ("</pre>"); 
			$Resultat[] = $ligne; //stockage des enregistrements dans $C
	}			
	return $Resultat;
}
//mysqli_num_rows ($res) > 0

function chercheLibelleNiveau($id_niveau){
	$link = connexion();

	$select= "select libelleNiveau from Niveau where idNiveau='%s'"; 
	$req = sprintf($select, $id_niveau);
	
	$res = mysqli_query($link, $req)	
		or die (utf8_encode("erreur de requête : ") . $req); 

		

	if (mysqli_num_rows ($res) > 0) {
			$f = utf8_encode('Résultat de la base : <br/>');
			$Res = mysqli_fetch_assoc($res);
		return $Res;
	}
}

function getPseudo($numerojoueur)
{
	$link = connexion();
	
	$select = "select pseudo from joueur where idJoueur = '%d'";
	$req = sprintf($select, $niveaujoueur);
}

function listeNiveau()
{
	$link = connexion();
	
	$select = "select idNiveau, libelleNiveau from niveau";
	
	$res = mysqli_query($link, $select) or die (utf8_encode("erreur de requête : ") . $select);
	 
	$Resultat= array();
	while ($ligne = mysqli_fetch_assoc($res) and isset($ligne)) {
			//echo ("<pre>"); var_dump($c); echo ("</pre>"); 
			$Resultat[] = $ligne; //stockage des enregistrements dans $C
	}			
	return $Resultat;
}
?>