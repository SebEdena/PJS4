<?php
function inscrireJoueur($pseudo,$email,$mdp)
{
	require("./Modele/connectBD.php");
	print_r($mdp);
	$sql = "insert into joueur(`pseudo`, `passe`, `email`) VALUES ('%s', '%s', '%s')";
	$req = sprintf($sql,$pseudo,$mdp,$email);
	
	mysqli_query($link, $req) or die (utf8_encode("erreur de requ�te : ") . $req);
}

?>