<?php 
	function ajouterPartie($idNiveau,$Score)
	{
		$sql = 'insert into
	}
?>